﻿Module CodeVault

    Public gv_dbName As String = "CodeVault.db"
    Public gvSCT As String 'Search Code Type
    Public gvTxType As String 'Enter or View 
    Public gvDelete As String 'Used on frmGridView

    Public gvCodeDes As String   'Used to move value
    Public gvCodeType As String  'from Enter New Code
    Public gvUIProject As String 'to View Code to save in DB

    Public gvID As Integer
    Public gvalertType As String

End Module
