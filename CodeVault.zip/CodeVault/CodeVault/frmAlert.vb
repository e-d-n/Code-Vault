﻿Public Class frmAlert
    Private Sub frmAlert_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If gvalertType = "1" Then
            tbAlert.Text = vbCrLf & "Select the Code Type"
        ElseIf gvalertType = "2" Then
            tbAlert.Text = vbCrLf & "Enter the Code Type"
        ElseIf gvalertType = "3" Then
            tbAlert.Text = vbCrLf & "Enter Used in Project"
        ElseIf gvalertType = "4" Then
            tbAlert.Text = vbCrLf & "No Clicking Here" & vbCrLf & "Click on the Code Description "
        ElseIf gvalertType = "5" Then
            tbAlert.Text = vbCrLf & "Cell Is Empty" & vbCrLf & "Click on the Code Description "
        ElseIf gvalertType = "6" Then
            tbAlert.Text = vbCrLf & "Code Type Can't be EMPTY" & vbCrLf & "Enter Code Type to Save New Type"
        ElseIf gvalertType = "7" Then
            tbAlert.Text = vbCrLf & "Code Type Can't be EMPTY" & vbCrLf & "Select a Current Type to Delete"
        ElseIf gvalertType = "8" Then
            tbAlert.Text = vbCrLf & "You are Creating DUPLICATES" & vbCrLf & "NO DUPLICATES"
        ElseIf gvalertType = "9" Then
            tbAlert.Text = vbCrLf & "No Code to Save to DB" & vbCrLf & "Click 'Get Code' to Search for Code"
        ElseIf gvalertType = "10" Then
            tbAlert.Text = vbCrLf & "No Code to Save to File"
        ElseIf gvalertType = "11" Then
            tbAlert.Text = vbCrLf & "File Name NOT Entered"
        ElseIf gvalertType = "12" Then
            tbAlert.Text = vbCrLf & "No Code to Copy"
        ElseIf gvalertType = "13" Then
            tbAlert.Text = vbCrLf & "Clipboard Containes No Code To Paste"
        End If
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Close()
    End Sub
End Class