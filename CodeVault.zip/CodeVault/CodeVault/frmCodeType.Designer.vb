﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCodeType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCodeType))
        Me.lblCurType = New System.Windows.Forms.Label()
        Me.btnDType = New System.Windows.Forms.Button()
        Me.btnSType = New System.Windows.Forms.Button()
        Me.tbType = New System.Windows.Forms.TextBox()
        Me.lblTypeName = New System.Windows.Forms.Label()
        Me.cbType = New System.Windows.Forms.ComboBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCurType
        '
        Me.lblCurType.AutoSize = True
        Me.lblCurType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurType.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblCurType.Location = New System.Drawing.Point(36, 37)
        Me.lblCurType.Name = "lblCurType"
        Me.lblCurType.Size = New System.Drawing.Size(150, 25)
        Me.lblCurType.TabIndex = 42
        Me.lblCurType.Text = "Current Types"
        '
        'btnDType
        '
        Me.btnDType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDType.Location = New System.Drawing.Point(194, 189)
        Me.btnDType.Name = "btnDType"
        Me.btnDType.Size = New System.Drawing.Size(160, 35)
        Me.btnDType.TabIndex = 41
        Me.btnDType.Text = "Delete Type"
        Me.btnDType.UseVisualStyleBackColor = True
        '
        'btnSType
        '
        Me.btnSType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSType.Location = New System.Drawing.Point(394, 189)
        Me.btnSType.Name = "btnSType"
        Me.btnSType.Size = New System.Drawing.Size(160, 35)
        Me.btnSType.TabIndex = 40
        Me.btnSType.Text = "Save Type"
        Me.btnSType.UseVisualStyleBackColor = True
        '
        'tbType
        '
        Me.tbType.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tbType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbType.Location = New System.Drawing.Point(194, 122)
        Me.tbType.MaxLength = 12
        Me.tbType.Name = "tbType"
        Me.tbType.Size = New System.Drawing.Size(190, 30)
        Me.tbType.TabIndex = 39
        '
        'lblTypeName
        '
        Me.lblTypeName.AutoSize = True
        Me.lblTypeName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTypeName.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblTypeName.Location = New System.Drawing.Point(81, 128)
        Me.lblTypeName.Name = "lblTypeName"
        Me.lblTypeName.Size = New System.Drawing.Size(105, 25)
        Me.lblTypeName.TabIndex = 38
        Me.lblTypeName.Text = "Site Type"
        '
        'cbType
        '
        Me.cbType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbType.FormattingEnabled = True
        Me.cbType.Location = New System.Drawing.Point(194, 34)
        Me.cbType.MaxLength = 12
        Me.cbType.Name = "cbType"
        Me.cbType.Size = New System.Drawing.Size(190, 33)
        Me.cbType.TabIndex = 37
        Me.cbType.TabStop = False
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(41, 189)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(111, 35)
        Me.btnCancel.TabIndex = 36
        Me.btnCancel.Text = "CANCEL"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmCodeType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 270)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblCurType)
        Me.Controls.Add(Me.btnDType)
        Me.Controls.Add(Me.btnSType)
        Me.Controls.Add(Me.tbType)
        Me.Controls.Add(Me.lblTypeName)
        Me.Controls.Add(Me.cbType)
        Me.Controls.Add(Me.btnCancel)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmCodeType"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Enter Code Types"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCurType As Label
    Friend WithEvents btnDType As Button
    Friend WithEvents btnSType As Button
    Friend WithEvents tbType As TextBox
    Friend WithEvents lblTypeName As Label
    Friend WithEvents cbType As ComboBox
    Friend WithEvents btnCancel As Button
End Class
