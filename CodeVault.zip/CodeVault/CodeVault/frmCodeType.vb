﻿Imports System.Data.SQLite

Public Class frmCodeType

    Private Sub frmLinkType_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FillComboBox()

    End Sub

    Private Sub btnSType_Click(sender As Object, e As EventArgs) Handles btnSType.Click

        If tbType.Text = "" Then
            gvalertType = "6"
            frmAlert.ShowDialog()
            tbType.Focus()
            Return
        End If

        Dim fn As String
        For Each fn In cbType.Items
            If fn = tbType.Text Then
                gvalertType = "8"
                frmAlert.ShowDialog()
                cbType.Text = fn
                tbType.Clear()
                Return
            End If
        Next

        InsertTypeData()

    End Sub

    Private Sub InsertTypeData()

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()

            Using cmd As New SQLiteCommand
                cmd.Connection = conn

                cmd.CommandText = "INSERT INTO TypeTable (ttType) VALUES (@ttType)"
                cmd.Parameters.Add("@ttType", DbType.String).Value = tbType.Text.Trim

                cmd.ExecuteNonQuery()

            End Using
        End Using

        frmStart.Show()
        Close()

    End Sub

    Private Sub FillComboBox()

        Dim intID As Integer
        Dim strTypeLink As String

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()
            Using cmd As New SQLiteCommand("", conn)
                cmd.CommandText = "SELECT * FROM TypeTable"

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader

                    While rdr.Read()
                        intID = CInt((rdr("TID")))
                        strTypeLink = rdr("ttType").ToString

                        cbType.Items.Add(strTypeLink)
                        'cbType.SelectedIndex = 0
                        'Code line Above displays first item in Combobo
                        '===============================================
                    End While

                End Using
            End Using
        End Using
    End Sub

    Private Sub cbType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbType.SelectedIndexChanged
        tbType.Text = cbType.Text
    End Sub

    Private Sub btnDType_Click(sender As Object, e As EventArgs) Handles btnDType.Click

        If cbType.Text = "" Then
            gvalertType = "7"
            frmAlert.ShowDialog()
            cbType.Focus()
            Return
        End If

        DeleteTypeData()

    End Sub

    Private Sub DeleteTypeData()

        Dim delID As Integer
        Dim strT As String

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()
            Using cmd As New SQLiteCommand("", conn)

                cmd.CommandText = "SELECT * FROM TypeTable WHERE ttType = @site"
                cmd.Parameters.Add("@site", DbType.String).Value = tbType.Text

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader

                    While rdr.Read()
                        delID = CInt((rdr("TID")))
                        strT = rdr("ttType").ToString
                    End While

                End Using
                'cbID.Items.RemoveAt(0)
                'How to clear a Combobox
                '=======================
                cmd.Connection = conn
                cmd.CommandText = "DELETE FROM TypeTable WHERE TID =" & delID
                cmd.ExecuteNonQuery()

            End Using
        End Using

        frmStart.Show()
        Close()

    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmStart.Show()
        Close()
    End Sub

End Class