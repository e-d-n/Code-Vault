﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEnterNewCode
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEnterNewCode))
        Me.tbProject = New System.Windows.Forms.TextBox()
        Me.lblProject = New System.Windows.Forms.Label()
        Me.lblCodeType = New System.Windows.Forms.Label()
        Me.cbType = New System.Windows.Forms.ComboBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.tbCodeDes = New System.Windows.Forms.TextBox()
        Me.lblCodeDesc = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnGet = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tbProject
        '
        Me.tbProject.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tbProject.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbProject.Location = New System.Drawing.Point(201, 134)
        Me.tbProject.MaxLength = 21
        Me.tbProject.Name = "tbProject"
        Me.tbProject.Size = New System.Drawing.Size(340, 34)
        Me.tbProject.TabIndex = 2
        '
        'lblProject
        '
        Me.lblProject.AutoSize = True
        Me.lblProject.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProject.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblProject.Location = New System.Drawing.Point(37, 140)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(158, 25)
        Me.lblProject.TabIndex = 55
        Me.lblProject.Text = "Used in Project"
        '
        'lblCodeType
        '
        Me.lblCodeType.AutoSize = True
        Me.lblCodeType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodeType.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblCodeType.Location = New System.Drawing.Point(443, 21)
        Me.lblCodeType.Name = "lblCodeType"
        Me.lblCodeType.Size = New System.Drawing.Size(119, 25)
        Me.lblCodeType.TabIndex = 54
        Me.lblCodeType.Text = "Code Type"
        '
        'cbType
        '
        Me.cbType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbType.FormattingEnabled = True
        Me.cbType.Location = New System.Drawing.Point(448, 59)
        Me.cbType.MaxLength = 12
        Me.cbType.Name = "cbType"
        Me.cbType.Size = New System.Drawing.Size(188, 33)
        Me.cbType.TabIndex = 1
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(207, 218)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(166, 35)
        Me.btnDelete.TabIndex = 4
        Me.btnDelete.Text = "Delete Code"
        Me.btnDelete.UseVisualStyleBackColor = True
        Me.btnDelete.Visible = False
        '
        'tbCodeDes
        '
        Me.tbCodeDes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tbCodeDes.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCodeDes.Location = New System.Drawing.Point(33, 59)
        Me.tbCodeDes.MaxLength = 21
        Me.tbCodeDes.Name = "tbCodeDes"
        Me.tbCodeDes.Size = New System.Drawing.Size(340, 34)
        Me.tbCodeDes.TabIndex = 0
        '
        'lblCodeDesc
        '
        Me.lblCodeDesc.AutoSize = True
        Me.lblCodeDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodeDesc.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblCodeDesc.Location = New System.Drawing.Point(28, 21)
        Me.lblCodeDesc.Name = "lblCodeDesc"
        Me.lblCodeDesc.Size = New System.Drawing.Size(167, 25)
        Me.lblCodeDesc.TabIndex = 50
        Me.lblCodeDesc.Text = "Code Decription"
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(42, 218)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(111, 35)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "CANCEL"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnGet
        '
        Me.btnGet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGet.Location = New System.Drawing.Point(448, 218)
        Me.btnGet.Name = "btnGet"
        Me.btnGet.Size = New System.Drawing.Size(166, 35)
        Me.btnGet.TabIndex = 3
        Me.btnGet.Text = "Get Code"
        Me.btnGet.UseVisualStyleBackColor = True
        '
        'frmEnterNewCode
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(690, 316)
        Me.ControlBox = False
        Me.Controls.Add(Me.tbProject)
        Me.Controls.Add(Me.lblProject)
        Me.Controls.Add(Me.lblCodeType)
        Me.Controls.Add(Me.cbType)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.tbCodeDes)
        Me.Controls.Add(Me.lblCodeDesc)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnGet)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmEnterNewCode"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Enter New Code"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbProject As TextBox
    Friend WithEvents lblProject As Label
    Friend WithEvents lblCodeType As Label
    Friend WithEvents cbType As ComboBox
    Friend WithEvents btnDelete As Button
    Friend WithEvents tbCodeDes As TextBox
    Friend WithEvents lblCodeDesc As Label
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnGet As Button
End Class
