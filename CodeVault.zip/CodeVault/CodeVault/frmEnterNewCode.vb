﻿Imports System.Data.SQLite

Public Class frmEnterNewCode
    Private Sub frmEnterNewCode_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FillComboBox()
    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnGet.Click
        If tbCodeDes.Text = "" Then
            gvalertType = "2"
            frmAlert.ShowDialog()
            tbCodeDes.Focus()
            Return
        End If
        If cbType.Text = "" Then
            gvalertType = "1"
            frmAlert.ShowDialog()
            cbType.Focus()
            Return
        End If
        If tbProject.Text = "" Then
            gvalertType = "3"
            frmAlert.ShowDialog()
            tbProject.Focus()
            Return
        End If

        gvCodeDes = tbCodeDes.Text.Trim
        gvCodeType = cbType.Text.Trim
        gvUIProject = tbProject.Text.Trim
        'Global Variables to Save to DB on frmViewCode
        '=============================================

        frmViewCode.Show()
        Close()

    End Sub

    Private Sub FillComboBox()

        Dim intID As Integer
        Dim strTypeLink As String

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()
            Using cmd As New SQLiteCommand("", conn)
                cmd.CommandText = "SELECT * FROM TypeTable"

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader

                    While rdr.Read()
                        intID = CInt((rdr("TID")))
                        strTypeLink = rdr("ttType").ToString

                        cbType.Items.Add(strTypeLink)
                        'cbType.SelectedIndex = 0
                        'Code line Above displays first item in Combobo
                        '===============================================
                    End While

                End Using
            End Using
        End Using
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmStart.Show()
        Close()
    End Sub
End Class