﻿Imports System.ComponentModel
Imports System.Data.SQLite

Public Class frmGridView
    Dim selRow As Integer

    Private Sub frmGridView_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        StyleDGV()
        ViewSearches()
    End Sub

    Private Sub StyleDGV()

        'Sets Design of the DataGridView
        '===============================
        dgvSelCode.DefaultCellStyle.Font = New Font("Times New Roman", 13.0F, FontStyle.Bold)
        dgvSelCode.ColumnCount = 4
        dgvSelCode.Columns(0).Width = 60   'ID
        dgvSelCode.Columns(1).Width = 256  'codeDesc 256
        dgvSelCode.Columns(2).Width = 310  'codeDesc 310
        dgvSelCode.Columns(3).Width = 170  'codeType 10

        'Option with no blank rows increase col count to 5
        'OR increase width of col(3) WHY? because the scroll bar is not showing 
        ' TOTAL Width 870 Height 296
        ' Row Height set to 32 continue to REVIEW
        '==========================================
        'To Set Col Header Size Mode = Enabled
        'To Set Col Header Default Cell Styles DO in Properties
        'dgvSelCode.Columns(6).DefaultCellStyle.Format = "c"

        dgvSelCode.ColumnHeadersHeight = 10 'Sans Serif 'Tahoma
        dgvSelCode.ColumnHeadersDefaultCellStyle.Font = New Font("Sans Serif", 12.0F, FontStyle.Bold)

        dgvSelCode.ColumnHeadersDefaultCellStyle.ForeColor = Color.Blue
        dgvSelCode.DefaultCellStyle.BackColor = Color.LightGoldenrodYellow

        'DGV Header Names
        dgvSelCode.Columns(0).Name = "CID"
        dgvSelCode.Columns(1).Name = "Code Description"
        dgvSelCode.Columns(2).Name = "Used in Project"
        dgvSelCode.Columns(3).Name = "Code Type"

        dgvSelCode.Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
        dgvSelCode.Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
        dgvSelCode.Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable
        dgvSelCode.Columns(3).SortMode = DataGridViewColumnSortMode.NotSortable

    End Sub

    Private Sub ViewSearches()

        Dim intID As Integer
        Dim strCodeDesc As String
        Dim strUIProject As String
        Dim strCodeType As String
        Dim rowCount As Integer
        Dim maxRowCount As Integer

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()

            Using cmd As New SQLiteCommand("", conn)

                If gvTxType = "View" Then
                    cmd.CommandText = "SELECT * FROM CodeTable WHERE cvCodeType = @site"
                    cmd.Parameters.Add("@site", DbType.String).Value = gvSCT
                ElseIf gvTxType = "All" Then
                    cmd.CommandText = "SELECT * FROM CodeTable"
                End If

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader

                    While rdr.Read()
                        intID = CInt((rdr("CID")))
                        strCodeDesc = rdr("cvCodeDesc").ToString
                        strUIProject = rdr("cvUIProject").ToString
                        strCodeType = rdr("cvCodeType").ToString

                        dgvSelCode.Rows.Add(intID, strCodeDesc, strUIProject, strCodeType)
                        rowCount += 1

                    End While

                    dgvSelCode.Sort(dgvSelCode.Columns(3), ListSortDirection.Ascending)

                End Using
                If rowCount <= 12 Then
                    maxRowCount = 12 - rowCount
                    For iA = 1 To maxRowCount
                        dgvSelCode.Rows.Add(" ")
                    Next
                End If

            End Using

        End Using

    End Sub

    Private Sub dgvSelCode_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvSelCode.CellClick

        selRow = e.RowIndex

        If e.RowIndex = -1 Then
            gvalertType = "4"
            frmAlert.ShowDialog()
            Exit Sub
        End If

        'Dim col As DataGridViewColumn = Me.dgvLinks.Columns(e.ColumnIndex)
        Dim row As DataGridViewRow = Me.dgvSelCode.Rows(e.RowIndex)
        If row.Cells(2).Value Is Nothing Then
            gvalertType = "5"
            frmAlert.ShowDialog()
            Return
            Exit Sub
        ElseIf gvTxType = "View" Or gvTxType = "All" And gvDelete <> "Delete" Then
            gvID = CInt(row.Cells(0).Value.ToString())
            frmViewCode.Show()
            Close()
        ElseIf gvDelete = "Delete" And gvTxType = "All" Then
            gvID = CInt(row.Cells(0).Value.ToString())
            DeleteCodeData()
        End If
    End Sub

    Private Sub DeleteCodeData()

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()

            Using cmd As New SQLiteCommand

                cmd.Connection = conn
                cmd.CommandText = "DELETE FROM CodeTable WHERE CID =" & gvID
                cmd.ExecuteNonQuery()

            End Using
        End Using

        gvDelete = ""
        gvTxType = ""
        frmStart.Show()
        Close()

    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmStart.Show()
        Close()
    End Sub

End Class