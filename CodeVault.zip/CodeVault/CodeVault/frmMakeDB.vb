﻿Imports System.Data.SQLite

Public Class frmMakeDB
    Public connStr As String = "Data Source={0};Version=3;"
    Public conn As SQLiteConnection

    Private Sub frmMakeDB_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim txString As String
        txString = vbCrLf & "Click CREATE to make the Database" & vbCrLf & "and make the Database Tables"
        tbMessage.Text = txString
        connStr = String.Format(connStr, gv_dbName)
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click

        makeDB()
        makeCodeTable()
        makeTypeTable()
        frmStart.Show()
        Close()

    End Sub
    Public Sub makeDB()
        If Not My.Computer.FileSystem.FileExists(gv_dbName) Then
            Try
                conn = New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
                conn.Open()
            Catch ex As Exception
                tbMessage.Text = "DB and Tables NOT Created"
            End Try
        End If
    End Sub

    Public Sub makeCodeTable()

        Dim create_table As String = String.Empty
        create_table = "CREATE TABLE IF NOT EXISTS CodeTable(
                        CID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                        cvCodeDesc TEXT,
                        cvCodeType TEXT,
                        cvUIProject TEXT,
                        cvCode TEXT)"

        Dim dbTable As String = "CodeTable"

        If Not My.Computer.FileSystem.FileExists(dbTable) Then
            Try
                Using conn As New SQLiteConnection(connStr)
                    conn.Open()
                    Using cmd As New SQLiteCommand(create_table, conn)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                tbMessage.Text = "Code Table FAILED"
            End Try
        End If

    End Sub

    Public Sub makeTypeTable()

        Dim create_table As String = String.Empty
        create_table = "CREATE TABLE IF NOT EXISTS TypeTable(
                        TID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                        ttType TEXT)"

        Dim dbTable As String = "TypeTable"

        If Not My.Computer.FileSystem.FileExists(dbTable) Then
            Try
                Using conn As New SQLiteConnection(connStr)
                    conn.Open()
                    Using cmd As New SQLiteCommand(create_table, conn)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
            Catch ex As Exception
                tbMessage.Text = "Type Table FAILED"
            End Try
        End If

    End Sub
End Class