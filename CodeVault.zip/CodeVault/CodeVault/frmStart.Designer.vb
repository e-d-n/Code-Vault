﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStart))
        Me.btnEnterCode = New System.Windows.Forms.Button()
        Me.btnCreateDB = New System.Windows.Forms.Button()
        Me.lblCodeType = New System.Windows.Forms.Label()
        Me.cbType = New System.Windows.Forms.ComboBox()
        Me.lblESC = New System.Windows.Forms.Label()
        Me.btnMCT = New System.Windows.Forms.Button()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.btnViewCode = New System.Windows.Forms.Button()
        Me.btnCreateFile = New System.Windows.Forms.Button()
        Me.btnViewAll = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnEnterCode
        '
        Me.btnEnterCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnterCode.Location = New System.Drawing.Point(469, 251)
        Me.btnEnterCode.Name = "btnEnterCode"
        Me.btnEnterCode.Size = New System.Drawing.Size(257, 35)
        Me.btnEnterCode.TabIndex = 0
        Me.btnEnterCode.Text = "Enter Code Snippet"
        Me.btnEnterCode.UseVisualStyleBackColor = True
        '
        'btnCreateDB
        '
        Me.btnCreateDB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateDB.ForeColor = System.Drawing.SystemColors.Desktop
        Me.btnCreateDB.Location = New System.Drawing.Point(47, 21)
        Me.btnCreateDB.Name = "btnCreateDB"
        Me.btnCreateDB.Size = New System.Drawing.Size(160, 35)
        Me.btnCreateDB.TabIndex = 1
        Me.btnCreateDB.Text = "Create DB"
        Me.btnCreateDB.UseVisualStyleBackColor = True
        '
        'lblCodeType
        '
        Me.lblCodeType.AutoSize = True
        Me.lblCodeType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodeType.Location = New System.Drawing.Point(42, 81)
        Me.lblCodeType.Name = "lblCodeType"
        Me.lblCodeType.Size = New System.Drawing.Size(263, 25)
        Me.lblCodeType.TabIndex = 33
        Me.lblCodeType.Text = "Select Code Type to View"
        Me.lblCodeType.Visible = False
        '
        'cbType
        '
        Me.cbType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbType.FormattingEnabled = True
        Me.cbType.Location = New System.Drawing.Point(47, 121)
        Me.cbType.Name = "cbType"
        Me.cbType.Size = New System.Drawing.Size(250, 33)
        Me.cbType.TabIndex = 32
        Me.cbType.TabStop = False
        Me.cbType.Visible = False
        '
        'lblESC
        '
        Me.lblESC.AutoSize = True
        Me.lblESC.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.lblESC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblESC.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblESC.Location = New System.Drawing.Point(511, 327)
        Me.lblESC.Name = "lblESC"
        Me.lblESC.Size = New System.Drawing.Size(184, 25)
        Me.lblESC.TabIndex = 31
        Me.lblESC.Text = "Press ESC to Exit"
        '
        'btnMCT
        '
        Me.btnMCT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMCT.Location = New System.Drawing.Point(469, 119)
        Me.btnMCT.Name = "btnMCT"
        Me.btnMCT.Size = New System.Drawing.Size(257, 35)
        Me.btnMCT.TabIndex = 34
        Me.btnMCT.Text = "Manage Code Type"
        Me.btnMCT.UseVisualStyleBackColor = True
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog"
        '
        'btnViewCode
        '
        Me.btnViewCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewCode.Location = New System.Drawing.Point(32, 185)
        Me.btnViewCode.Name = "btnViewCode"
        Me.btnViewCode.Size = New System.Drawing.Size(389, 35)
        Me.btnViewCode.TabIndex = 35
        Me.btnViewCode.Text = "View Code Snippet by Code Type"
        Me.btnViewCode.UseVisualStyleBackColor = True
        '
        'btnCreateFile
        '
        Me.btnCreateFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateFile.Location = New System.Drawing.Point(32, 317)
        Me.btnCreateFile.Name = "btnCreateFile"
        Me.btnCreateFile.Size = New System.Drawing.Size(389, 35)
        Me.btnCreateFile.TabIndex = 36
        Me.btnCreateFile.Text = "View or Create Code File on C Drive"
        Me.btnCreateFile.UseVisualStyleBackColor = True
        '
        'btnViewAll
        '
        Me.btnViewAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewAll.Location = New System.Drawing.Point(469, 185)
        Me.btnViewAll.Name = "btnViewAll"
        Me.btnViewAll.Size = New System.Drawing.Size(257, 35)
        Me.btnViewAll.TabIndex = 37
        Me.btnViewAll.Text = "View All Code Snippets"
        Me.btnViewAll.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(32, 251)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(389, 35)
        Me.btnDelete.TabIndex = 38
        Me.btnDelete.Text = "Delete Code Snippet from DB"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnAbout
        '
        Me.btnAbout.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAbout.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAbout.ForeColor = System.Drawing.SystemColors.Desktop
        Me.btnAbout.Location = New System.Drawing.Point(656, 23)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(70, 35)
        Me.btnAbout.TabIndex = 103
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = False
        '
        'frmStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(775, 386)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnAbout)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnViewAll)
        Me.Controls.Add(Me.btnCreateFile)
        Me.Controls.Add(Me.btnViewCode)
        Me.Controls.Add(Me.btnMCT)
        Me.Controls.Add(Me.lblCodeType)
        Me.Controls.Add(Me.cbType)
        Me.Controls.Add(Me.lblESC)
        Me.Controls.Add(Me.btnCreateDB)
        Me.Controls.Add(Me.btnEnterCode)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frmStart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Code Vault"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnEnterCode As Button
    Friend WithEvents btnCreateDB As Button
    Friend WithEvents lblCodeType As Label
    Friend WithEvents cbType As ComboBox
    Friend WithEvents lblESC As Label
    Friend WithEvents btnMCT As Button
    Friend WithEvents OpenFileDialog As OpenFileDialog
    Friend WithEvents btnViewCode As Button
    Friend WithEvents btnCreateFile As Button
    Friend WithEvents btnViewAll As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnAbout As Button
End Class
