﻿Imports System.Data.SQLite

Public Class frmStart
    Public connStr As String = "Data Source={0};Version=3;"
    Public conn As SQLiteConnection

    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If My.Computer.FileSystem.FileExists(gv_dbName) Then
            btnCreateDB.Visible = False
            cbType.Visible = True
            lblCodeType.Visible = True
            FillComboBox()
            Me.Width = 785
            Me.Height = 420
            gvSCT = ""
            gvTxType = ""
            Me.Refresh()
        Else
            Me.Width = 265
            Me.Height = 190
            Me.Refresh()
            btnCreateDB.Visible = True
        End If

    End Sub
    Private Sub btnCreateDB_Click(sender As Object, e As EventArgs) Handles btnCreateDB.Click
        frmMakeDB.Show()
        Close()
    End Sub
    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        frmAbout.Show()
        Close()
    End Sub
    Private Sub btnEnterCode_Click(sender As Object, e As EventArgs) Handles btnEnterCode.Click
        gvTxType = "Enter"
        frmEnterNewCode.Show()
        Close()
    End Sub
    Private Sub btnViewAll_Click(sender As Object, e As EventArgs) Handles btnViewAll.Click
        gvTxType = "All"
        frmGridView.Show()
        Close()
    End Sub
    Private Sub btnViewCode_Click(sender As Object, e As EventArgs) Handles btnViewCode.Click
        If gvSCT = "" Then
            gvalertType = "1"
            frmAlert.ShowDialog()
            cbType.Text = ""
            cbType.DroppedDown = True
            cbType.Focus()
            Return
        End If
        gvTxType = "View"
        frmGridView.Show()
        Close()
    End Sub
    Private Sub btnCreateFile_Click(sender As Object, e As EventArgs) Handles btnCreateFile.Click
        gvTxType = "Create"
        frmViewCode.Show()
        Close()
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        gvDelete = "Delete"
        gvTxType = "All"
        frmGridView.Show()
        Close()

    End Sub
    Private Sub btnMCT_Click(sender As Object, e As EventArgs) Handles btnMCT.Click
        frmCodeType.Show()
        Close()
    End Sub
    Private Sub cbType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbType.SelectedIndexChanged
        gvSCT = cbType.Text
    End Sub
    Private Sub FillComboBox()

        Dim intID As Integer
        Dim strTypeLink As String

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()
            Using cmd As New SQLiteCommand("", conn)
                cmd.CommandText = "SELECT * FROM TypeTable"

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader

                    While rdr.Read()
                        intID = CInt((rdr("TID")))
                        strTypeLink = rdr("ttType").ToString

                        cbType.Items.Add(strTypeLink)
                        'cbType.SelectedIndex = 0
                        'Code line Above displays first item in Combobo
                        '===============================================
                    End While

                End Using
            End Using
        End Using
    End Sub

    Public Sub frmStart_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
        'Form Property KeyPreview needs to be set to True
        '=================================================
        If Asc(e.KeyChar) = 27 Then
            Application.Exit()
        End If
    End Sub


End Class
