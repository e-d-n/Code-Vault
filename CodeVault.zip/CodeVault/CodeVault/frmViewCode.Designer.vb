﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmViewCode
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmViewCode))
        Me.rtbViewCode = New System.Windows.Forms.RichTextBox()
        Me.btnCopy = New System.Windows.Forms.Button()
        Me.btnGetCode = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.tbTheCode = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnSaveFile = New System.Windows.Forms.Button()
        Me.lblFileName = New System.Windows.Forms.Label()
        Me.lblMsg = New System.Windows.Forms.Label()
        Me.btnMin = New System.Windows.Forms.Button()
        Me.btnPaste = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'rtbViewCode
        '
        Me.rtbViewCode.Cursor = System.Windows.Forms.Cursors.Default
        Me.rtbViewCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbViewCode.Location = New System.Drawing.Point(30, 27)
        Me.rtbViewCode.Name = "rtbViewCode"
        Me.rtbViewCode.Size = New System.Drawing.Size(1150, 980)
        Me.rtbViewCode.TabIndex = 1
        Me.rtbViewCode.Text = ""
        '
        'btnCopy
        '
        Me.btnCopy.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCopy.Location = New System.Drawing.Point(1225, 328)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(134, 36)
        Me.btnCopy.TabIndex = 21
        Me.btnCopy.Text = "Copy Code"
        Me.btnCopy.UseVisualStyleBackColor = True
        '
        'btnGetCode
        '
        Me.btnGetCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetCode.Location = New System.Drawing.Point(1225, 812)
        Me.btnGetCode.Name = "btnGetCode"
        Me.btnGetCode.Size = New System.Drawing.Size(202, 36)
        Me.btnGetCode.TabIndex = 20
        Me.btnGetCode.Text = "Get Code File"
        Me.btnGetCode.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(1261, 949)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(134, 36)
        Me.btnBack.TabIndex = 19
        Me.btnBack.Text = "BACK"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'tbTheCode
        '
        Me.tbTheCode.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tbTheCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTheCode.Location = New System.Drawing.Point(1198, 590)
        Me.tbTheCode.MaxLength = 21
        Me.tbTheCode.Name = "tbTheCode"
        Me.tbTheCode.Size = New System.Drawing.Size(299, 34)
        Me.tbTheCode.TabIndex = 0
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(1225, 740)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(202, 36)
        Me.btnSave.TabIndex = 23
        Me.btnSave.Text = "Save to DB"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnSaveFile
        '
        Me.btnSaveFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveFile.Location = New System.Drawing.Point(1225, 671)
        Me.btnSaveFile.Name = "btnSaveFile"
        Me.btnSaveFile.Size = New System.Drawing.Size(202, 36)
        Me.btnSaveFile.TabIndex = 24
        Me.btnSaveFile.Text = "Save New File"
        Me.btnSaveFile.UseVisualStyleBackColor = True
        '
        'lblFileName
        '
        Me.lblFileName.AutoSize = True
        Me.lblFileName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFileName.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblFileName.Location = New System.Drawing.Point(1220, 550)
        Me.lblFileName.Name = "lblFileName"
        Me.lblFileName.Size = New System.Drawing.Size(166, 25)
        Me.lblFileName.TabIndex = 100
        Me.lblFileName.Text = "Enter File Name"
        Me.lblFileName.Visible = False
        '
        'lblMsg
        '
        Me.lblMsg.AutoSize = True
        Me.lblMsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMsg.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblMsg.Location = New System.Drawing.Point(1220, 401)
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.Size = New System.Drawing.Size(120, 25)
        Me.lblMsg.TabIndex = 101
        Me.lblMsg.Text = "Code Vault"
        '
        'btnMin
        '
        Me.btnMin.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMin.ForeColor = System.Drawing.SystemColors.Desktop
        Me.btnMin.Location = New System.Drawing.Point(1342, 27)
        Me.btnMin.Name = "btnMin"
        Me.btnMin.Size = New System.Drawing.Size(101, 35)
        Me.btnMin.TabIndex = 102
        Me.btnMin.Text = "Minimize"
        Me.btnMin.UseVisualStyleBackColor = False
        '
        'btnPaste
        '
        Me.btnPaste.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPaste.Location = New System.Drawing.Point(1225, 247)
        Me.btnPaste.Name = "btnPaste"
        Me.btnPaste.Size = New System.Drawing.Size(134, 36)
        Me.btnPaste.TabIndex = 103
        Me.btnPaste.Text = "Paste Code"
        Me.btnPaste.UseVisualStyleBackColor = True
        '
        'frmViewCode
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1528, 1070)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnPaste)
        Me.Controls.Add(Me.btnMin)
        Me.Controls.Add(Me.lblMsg)
        Me.Controls.Add(Me.lblFileName)
        Me.Controls.Add(Me.btnSaveFile)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.tbTheCode)
        Me.Controls.Add(Me.btnCopy)
        Me.Controls.Add(Me.btnGetCode)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.rtbViewCode)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmViewCode"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View Code"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rtbViewCode As RichTextBox
    Friend WithEvents btnCopy As Button
    Friend WithEvents btnGetCode As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents tbTheCode As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents btnSaveFile As Button
    Friend WithEvents lblFileName As Label
    Friend WithEvents lblMsg As Label
    Friend WithEvents btnMin As Button
    Friend WithEvents btnPaste As Button
End Class
