﻿Imports System.Data.SQLite
Imports System.IO

Public Class frmViewCode

    Private Sub frmViewCode_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If gvTxType = "View" Then
            CodeView()
            btnSave.Visible = False
            tbTheCode.Visible = False
            btnSaveFile.Visible = False
            btnGetCode.Visible = False
        ElseIf gvTxType = "Create" Then
            tbTheCode.Focus()
            btnSaveFile.Visible = True
            btnSave.Visible = False
            tbTheCode.Visible = True
            lblFileName.Visible = True
            lblMsg.Text = "You can paste text and" & vbCrLf & "NOT use Get Code File"
        ElseIf gvTxType = "Enter" Then
            lblMsg.Text = "You can paste text and" & vbCrLf & "NOT use Get Code File"
            btnSave.Visible = True
            tbTheCode.Visible = False
            btnSaveFile.Visible = False
        ElseIf gvTxType = "All" Then
            CodeView()
            btnSave.Visible = False
            tbTheCode.Visible = False
            btnSaveFile.Visible = False
            btnGetCode.Visible = False
        End If

    End Sub
    Private Sub btnMin_Click(sender As Object, e As EventArgs) Handles btnMin.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    Private Sub CodeView()

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()

            Using cmd As New SQLiteCommand("", conn)
                If gvTxType = "View" Or gvTxType = "All" Then
                    cmd.CommandText = "SELECT * FROM CodeTable WHERE CID =" & gvID
                End If

                Using rdr As SQLite.SQLiteDataReader = cmd.ExecuteReader
                    While rdr.Read()
                        Dim strCode As String = rdr("cvCode").ToString
                        rtbViewCode.Text = strCode
                    End While
                End Using
            End Using
        End Using

    End Sub
    Private Sub btnViewFile_Click(sender As Object, e As EventArgs) Handles btnGetCode.Click
        Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
        Dim dr As DialogResult = openFileDialog.ShowDialog()

        If dr = System.Windows.Forms.DialogResult.OK Then

            Dim openPath As String = openFileDialog.FileName
            rtbViewCode.Text = File.ReadAllText(openPath)

        End If
    End Sub
    Private Sub btnPaste_Click(sender As Object, e As EventArgs) Handles btnPaste.Click

        If Clipboard.ContainsText(TextDataFormat.Text) Then
            rtbViewCode.SelectedText = Clipboard.GetData(DataFormats.Text).ToString()
        Else
            gvalertType = "13"
            frmAlert.ShowDialog()
            rtbViewCode.Focus()
            Return
        End If

    End Sub
    Private Sub btnCopy_Click(sender As Object, e As EventArgs) Handles btnCopy.Click
        If rtbViewCode.Text = "" Then
            gvalertType = "12"
            frmAlert.ShowDialog()
            Return
        End If
        rtbViewCode.SelectAll()
        rtbViewCode.Copy()
    End Sub
    Private Sub btnCopySelCode_Click(sender As Object, e As EventArgs) Handles btnCopySelCode.Click
        CopySelected()
    End Sub
    Public Sub CopySelected()
        Dim start = rtbViewCode.SelectionStart
        Dim substring = rtbViewCode.Text.Substring(0, start)
        Dim words = substring.Split(New String() {" ", vbCrLf}, StringSplitOptions.None)
        Dim gvW = rtbViewCode.SelectedText
        Dim count = gvW.Length
        If count <= 0 Then
            gvalertType = "14"
            frmAlert.ShowDialog()
            rtbViewCode.Focus()
            Return
        End If
        Clipboard.SetText(gvW)
        ansQ()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If rtbViewCode.Text = "" Then
            gvalertType = "9"
            frmAlert.ShowDialog()
            Return
        End If

        InsertCodeData()

    End Sub
    Private Sub InsertCodeData()

        Using conn As New SQLiteConnection($"Data Source = '{gv_dbName}';Version=3;")
            conn.Open()

            Using cmd As New SQLiteCommand
                cmd.Connection = conn
                Try
                    cmd.CommandText = "INSERT INTO CodeTable (cvCodeDesc,cvCodeType,cvUIProject,cvCode) VALUES (@cvCodeDesc,@cvCodeType,@cvUIProject,@cvCode)"

                    cmd.Parameters.Add("@cvCodeDesc", DbType.String).Value = gvCodeDes
                    cmd.Parameters.Add("@cvCodeType", DbType.String).Value = gvCodeType
                    cmd.Parameters.Add("@cvUIProject", DbType.String).Value = gvUIProject
                    cmd.Parameters.Add("@cvCode", DbType.String).Value = rtbViewCode.Text
                    cmd.ExecuteNonQuery()

                Catch ex As Exception
                    MsgBox("Insert Failed")
                End Try
            End Using
        End Using

        frmStart.Show()
        Close()

    End Sub

    Private Sub btnSaveFile_Click(sender As Object, e As EventArgs) Handles btnSaveFile.Click

        If tbTheCode.Text = "" Then
            gvalertType = "11"
            frmAlert.ShowDialog()
            tbTheCode.Focus()
            Return
        End If
        If rtbViewCode.Text = "" Then
            gvalertType = "10"
            frmAlert.ShowDialog()
            Return
        End If

        Dim folder As String = "C:\A A Code Vault\Data\"
        If Not System.IO.Directory.Exists(folder) Then
            System.IO.Directory.CreateDirectory(folder)
        End If

        svToFile()

    End Sub

    Private Sub svToFile()
        Dim sTarget As String = "C:\A A Code Vault\Data\" & tbTheCode.Text
        Dim fileEntries As String() = Directory.GetFiles("C:\A A Code Vault\Data\") ', "*.txt")
        ' Process the list of .txt files found in the directory. '

        Dim fN As String
        For Each fN In fileEntries
            If (System.IO.File.Exists(fN)) Then
                'MsgBox("File " & fN)
                If fN = sTarget Then
                    ansD()
                    'USE Yes/No/Cancel MessageBox HERE
                    '=================================
                    Exit Sub
                End If
            End If
        Next

        Try
            Dim filePath As String
            filePath = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.MyDocuments, "C:\A A Code Vault\Data\" & tbTheCode.Text)
            My.Computer.FileSystem.WriteAllText(filePath, rtbViewCode.Text, False)
        Catch fileException As Exception
            Throw fileException
        End Try
        gvTxType = ""
        frmStart.Show()
        Close()

    End Sub

    Public Sub ansD()
        Const Msg As String = "YES Delete Old File & Save New File" + vbCrLf + vbNewLine + "NO Enter New File Name" + vbCrLf + vbNewLine + "Cnacel and Exit"
        Const Title As String = "Delete & Save Enter New File Name OR Exit"
        Dim result = MessageBox.Show(Msg, Title, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

        If result = vbYes Then
            System.IO.File.Delete("C:\A A Code Vault\Data\" & tbTheCode.Text)
            Try
                Dim filePath As String
                filePath = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.MyDocuments, "C:\A A Code Vault\Data\" & tbTheCode.Text)
                My.Computer.FileSystem.WriteAllText(filePath, rtbViewCode.Text, False)
            Catch fileException As Exception
                Throw fileException
            End Try
            gvTxType = ""
            frmStart.Show()
            Close()
        ElseIf result = vbNo Then
            tbTheCode.Focus()
        ElseIf result = vbCancel Then
            gvTxType = ""
            frmStart.Show()
            Close()
        End If

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        If Clipboard.ContainsText Then
            ansQ()
        Else
            rtbViewCode.Clear()
            frmStart.Show()
            Close()
        End If
    End Sub

    Public Sub ansQ()
        Const Msg As String = "YES Clear Cipboard" + vbCrLf + vbNewLine + "NO    Exit"
        Const Title As String = "Clear Clipboard or Exit"

        Dim result = MessageBox.Show(Msg, Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = vbYes Then
            rtbViewCode.Clear()
            Clipboard.Clear()
            frmStart.Show()
            Close()
        ElseIf result = vbNo Then
            rtbViewCode.Clear()
            frmStart.Show()
            Close()
        End If
    End Sub

End Class